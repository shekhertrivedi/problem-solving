package models

type Vehicle interface {
	GetNumber() string
	GetColor() string
}
